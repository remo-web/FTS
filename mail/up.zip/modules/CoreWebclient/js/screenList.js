'use strict';

module.exports = {
	'header': function () {
		return require('%PathToCoreWebclientModule%/js/views/HeaderView.js');
	},
	'information': function () {
		return require('%PathToCoreWebclientModule%/js/views/InformationView.js');
	}
};
