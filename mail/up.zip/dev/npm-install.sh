#!/bin/bash

cd ../
npm install ./modules/CoreWebclient